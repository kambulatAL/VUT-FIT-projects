/*
***************************************************************
*                         IFJ22                               *
***************************************************************
* @file main.c
* @author Kambulat Alakaev (xalaka00@stud.fit.vutbr.cz)
*/

#include "parser.h"

int main() {
    FILE *input = stdin;
   
    RunParser(input);
    return 0;
}
